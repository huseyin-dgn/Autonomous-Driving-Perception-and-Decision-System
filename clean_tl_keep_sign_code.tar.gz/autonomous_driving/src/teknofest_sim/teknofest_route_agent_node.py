import json
import math
import os
import sys
import time

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

from teknofest_sim.carla_loader import load_carla


class TeknofestRouteAgentNode(Node):
    def __init__(self):
        super().__init__("teknofest_route_agent_node")

        self.declare_parameter("carla_root", "/home/ilker/simulators/CARLA_0.9.15")
        self.declare_parameter("host", "127.0.0.1")
        self.declare_parameter("port", 2000)
        self.declare_parameter("timeout", 120.0)
        self.declare_parameter("ego_role_name", "ego_vehicle")

        self.declare_parameter("decision_topic", "/adas/decision")
        self.declare_parameter("mission_topic", "/adas/teknofest/mission")

        # Yarışma modu:
        # Mission node sadece görev hedefini verir.
        # GlobalRoutePlannerNode bu hedefe runtime rota üretir.
        # RouteAgent artık mümkünse /adas/planning/local_target takip eder.
        self.declare_parameter("use_planner_local_target", True)
        self.declare_parameter("local_target_topic", "/adas/planning/local_target")
        self.declare_parameter("planner_fresh_timeout_s", 1.0)
        self.declare_parameter("planner_speed_hint_enabled", True)
        self.declare_parameter("planner_local_target_as_destination", False)
        self.declare_parameter("planner_destination_hold_enabled", True)
        self.declare_parameter("planner_destination_reached_m", 7.0)
        self.declare_parameter("planner_destination_update_min_distance_m", 18.0)
        self.declare_parameter("planner_destination_update_min_interval_s", 2.0)
        self.declare_parameter("planner_target_key_resolution_m", 3.0)
        self.declare_parameter("target_speed_smoothing_enabled", True)
        self.declare_parameter("target_speed_accel_limit_mps2", 1.8)
        self.declare_parameter("target_speed_decel_limit_mps2", 3.0)

        self.declare_parameter("debug_topic", "/adas/teknofest/route_agent_debug")
        self.declare_parameter("collision_topic", "/adas/events/collision")
        self.declare_parameter("collision_halt_s", 4.0)

        self.declare_parameter("control_rate_hz", 20.0)
        self.declare_parameter("max_speed_mps", 4.0)
        self.declare_parameter("go_speed_mps", 3.2)
        self.declare_parameter("slow_speed_mps", 1.4)
        self.declare_parameter("parking_speed_mps", 0.65)

        # İnsan/launch tarafı km/h. Verilirse m/s değerlerini override eder.
        self.declare_parameter("max_speed_kmh", -1.0)
        self.declare_parameter("go_speed_kmh", -1.0)
        self.declare_parameter("slow_speed_kmh", -1.0)
        self.declare_parameter("parking_speed_kmh", -1.0)
        self.declare_parameter("green_release_speed_kmh", -1.0)

        # BasicAgent direksiyonu kendi üretir. Bunu çok düşük tutarsan araç dönemiyor.
        self.declare_parameter("max_steer", 0.70)
        self.declare_parameter("lane_assist_enabled", True)
        self.declare_parameter("lane_topic", "/adas/lane/assist")
        self.declare_parameter("lane_min_confidence", 0.60)
        self.declare_parameter("lane_fresh_timeout_s", 0.50)
        self.declare_parameter("lane_blend_straight", 0.35)
        self.declare_parameter("lane_blend_turn", 0.12)
        self.declare_parameter("lane_turn_steer_threshold", 0.28)
        self.declare_parameter("lane_allowed_stages", "GO_TO_TASK,GO_TO_PARK")

        self.declare_parameter("mission_stop_override", True)
        self.declare_parameter("ignore_decision_for_mission_test", True)

        # CARLA_TL_GUARD_FIX:
        # Simülasyonda vision yanlış kırmızıya kilitlenirse CARLA'nın gerçek
        # trafik ışığı state'i ile emniyetli şekilde düzelt.
        self.declare_parameter("carla_tl_override_enabled", True)
        self.declare_parameter("ignore_vision_red_when_carla_not_red", True)
        self.declare_parameter("post_tl_ignore_s", 7.0)
        self.declare_parameter("green_release_speed_mps", 4.0)
        self.declare_parameter("green_release_boost_s", 2.5)

        # CARLA_TL_LOOKAHEAD_GUARD:
        # ego.is_at_traffic_light() bazen trigger alanına girene kadar False kalıyor.
        # Bu yüzden öndeki CARLA traffic_light actor'larının stop waypoint/trigger noktalarını
        # tarayıp kırmızı/sarı ışığı daha erken yakalıyoruz.
        self.declare_parameter("carla_tl_lookahead_enabled", True)
        self.declare_parameter("carla_tl_lookahead_distance_m", 55.0)
        self.declare_parameter("carla_tl_lookahead_min_distance_m", 4.0)
        self.declare_parameter("carla_tl_lookahead_lateral_m", 7.5)
        self.declare_parameter("carla_tl_lookahead_fov_deg", 35.0)
        self.declare_parameter("carla_tl_lookahead_same_dir_dot", 0.10)

        self.carla_root = self.get_parameter("carla_root").value
        self.host = self.get_parameter("host").value
        self.port = int(self.get_parameter("port").value)
        self.timeout = float(self.get_parameter("timeout").value)
        self.ego_role_name = self.get_parameter("ego_role_name").value

        self.decision_topic = self.get_parameter("decision_topic").value
        self.mission_topic = self.get_parameter("mission_topic").value

        self.use_planner_local_target = bool(
            self.get_parameter("use_planner_local_target").value
        )
        self.local_target_topic = self.get_parameter("local_target_topic").value
        self.planner_fresh_timeout_s = float(
            self.get_parameter("planner_fresh_timeout_s").value
        )
        self.planner_speed_hint_enabled = bool(
            self.get_parameter("planner_speed_hint_enabled").value
        )
        self.planner_local_target_as_destination = bool(
            self.get_parameter("planner_local_target_as_destination").value
        )
        self.planner_destination_hold_enabled = bool(
            self.get_parameter("planner_destination_hold_enabled").value
        )
        self.planner_destination_reached_m = float(
            self.get_parameter("planner_destination_reached_m").value
        )
        self.planner_destination_update_min_distance_m = float(
            self.get_parameter("planner_destination_update_min_distance_m").value
        )
        self.planner_destination_update_min_interval_s = float(
            self.get_parameter("planner_destination_update_min_interval_s").value
        )
        self.last_agent_destination_set_time = 0.0
        self.active_planner_route_id = None
        self.planner_target_key_resolution_m = float(
            self.get_parameter("planner_target_key_resolution_m").value
        )
        self.target_speed_smoothing_enabled = bool(
            self.get_parameter("target_speed_smoothing_enabled").value
        )
        self.target_speed_accel_limit_mps2 = float(
            self.get_parameter("target_speed_accel_limit_mps2").value
        )
        self.target_speed_decel_limit_mps2 = float(
            self.get_parameter("target_speed_decel_limit_mps2").value
        )
        self.last_smoothed_target_speed_mps = None
        self.last_smoothed_target_time = 0.0

        self.debug_topic = self.get_parameter("debug_topic").value
        self.collision_topic = self.get_parameter("collision_topic").value

        self.collision_halt_s = float(self.get_parameter("collision_halt_s").value)
        self.collision_until = 0.0
        self.last_collision = None

        self.max_speed_mps = float(self.get_parameter("max_speed_mps").value)
        self.go_speed_mps = float(self.get_parameter("go_speed_mps").value)
        self.slow_speed_mps = float(self.get_parameter("slow_speed_mps").value)
        self.parking_speed_mps = float(self.get_parameter("parking_speed_mps").value)
        self.max_steer = float(self.get_parameter("max_steer").value)

        self.lane_assist_enabled = bool(self.get_parameter("lane_assist_enabled").value)
        self.lane_topic = self.get_parameter("lane_topic").value
        self.lane_min_confidence = float(self.get_parameter("lane_min_confidence").value)
        self.lane_fresh_timeout_s = float(self.get_parameter("lane_fresh_timeout_s").value)
        self.lane_blend_straight = float(self.get_parameter("lane_blend_straight").value)
        self.lane_blend_turn = float(self.get_parameter("lane_blend_turn").value)
        self.lane_turn_steer_threshold = float(self.get_parameter("lane_turn_steer_threshold").value)
        self.lane_allowed_stages = [
            x.strip() for x in str(self.get_parameter("lane_allowed_stages").value).split(",") if x.strip()
        ]

        self.mission_stop_override = bool(self.get_parameter("mission_stop_override").value)
        self.ignore_decision_for_mission_test = False

        self.carla_tl_override_enabled = bool(
            self.get_parameter("carla_tl_override_enabled").value
        )
        self.ignore_vision_red_when_carla_not_red = bool(
            self.get_parameter("ignore_vision_red_when_carla_not_red").value
        )
        self.post_tl_ignore_s = float(self.get_parameter("post_tl_ignore_s").value)
        self.green_release_speed_mps = float(
            self.get_parameter("green_release_speed_mps").value
        )
        self.green_release_boost_s = float(
            self.get_parameter("green_release_boost_s").value
        )

        self.carla_tl_lookahead_enabled = bool(
            self.get_parameter("carla_tl_lookahead_enabled").value
        )
        self.carla_tl_lookahead_distance_m = float(
            self.get_parameter("carla_tl_lookahead_distance_m").value
        )
        self.carla_tl_lookahead_min_distance_m = float(
            self.get_parameter("carla_tl_lookahead_min_distance_m").value
        )
        self.carla_tl_lookahead_lateral_m = float(
            self.get_parameter("carla_tl_lookahead_lateral_m").value
        )
        self.carla_tl_lookahead_fov_deg = float(
            self.get_parameter("carla_tl_lookahead_fov_deg").value
        )
        self.carla_tl_lookahead_same_dir_dot = float(
            self.get_parameter("carla_tl_lookahead_same_dir_dot").value
        )

        # km/h parametreleri verilirse iç m/s değerlerini burada override et.
        self.max_speed_kmh = float(self.get_parameter("max_speed_kmh").value)
        self.go_speed_kmh = float(self.get_parameter("go_speed_kmh").value)
        self.slow_speed_kmh = float(self.get_parameter("slow_speed_kmh").value)
        self.parking_speed_kmh = float(self.get_parameter("parking_speed_kmh").value)
        self.green_release_speed_kmh = float(self.get_parameter("green_release_speed_kmh").value)

        if self.max_speed_kmh >= 0.0:
            self.max_speed_mps = self.kmh_to_mps(self.max_speed_kmh)
        if self.go_speed_kmh >= 0.0:
            self.go_speed_mps = self.kmh_to_mps(self.go_speed_kmh)
        if self.slow_speed_kmh >= 0.0:
            self.slow_speed_mps = self.kmh_to_mps(self.slow_speed_kmh)
        if self.parking_speed_kmh >= 0.0:
            self.parking_speed_mps = self.kmh_to_mps(self.parking_speed_kmh)
        if self.green_release_speed_kmh >= 0.0:
            self.green_release_speed_mps = self.kmh_to_mps(self.green_release_speed_kmh)

        self.last_carla_tl_state = "unknown"
        self.last_carla_tl_at_light = False
        self.post_tl_ignore_until = 0.0
        self.green_release_until = 0.0
        self.tl_green_override_until = 0.0
        self.last_carla_tl_guard_debug = {
            "at_light": False,
            "state": "unknown",
            "source": "initial",
        }

        self.carla = load_carla(self.carla_root)
        self.client = self.carla.Client(self.host, self.port)
        self.client.set_timeout(self.timeout)
        self.world = self.client.get_world()
        self.map = self.world.get_map()
        self.ego = self.wait_for_ego()

        self.BasicAgent = self.load_basic_agent()
        self.agent = self.BasicAgent(self.ego, target_speed=self.go_speed_mps * 3.6)

        self.configure_agent_ignore_rules()

        self.latest_decision = {
            "decision": "STOP",
            "risk": "UNKNOWN",
            "target_speed": 0.0,
            "reason": "initial",
        }

        # Yasak dönüş/girilmez levhası gelince geçici lokal detour hedefi.
        self.forbidden_turn_request = None
        self.forbidden_turn_until = 0.0
        self.forbidden_detour_target = None
        self.last_forbidden_turn_key = None

        self.latest_mission = None
        self.last_decision_time = 0.0
        self.last_mission_time = 0.0

        self.latest_local_target = None
        self.last_local_target_time = 0.0

        self.active_target_key = None
        self.active_destination = None
        self.route_status = "not_planned"

        self.latest_lane = None
        self.last_lane_time = 0.0
        self.current_lane_debug = {
            "enabled": self.lane_assist_enabled,
            "used": False,
            "reason": "initial",
        }

        self.debug_pub = self.create_publisher(String, self.debug_topic, 10)

        self.create_subscription(String, self.decision_topic, self.decision_cb, 10)
        self.create_subscription(String, self.mission_topic, self.mission_cb, 10)
        self.create_subscription(String, self.local_target_topic, self.local_target_cb, 10)
        self.create_subscription(String, self.collision_topic, self.collision_cb, 10)
        self.create_subscription(String, self.lane_topic, self.lane_cb, 10)

        rate = float(self.get_parameter("control_rate_hz").value)
        self.timer = self.create_timer(1.0 / max(rate, 1.0), self.tick)

        self.get_logger().info("TEKNOFEST route agent hazır: CARLA BasicAgent lane follower aktif.")

    def load_basic_agent(self):
        possible_paths = [
            os.path.join(self.carla_root, "PythonAPI", "carla"),
            os.path.join(self.carla_root, "PythonAPI"),
            os.path.expanduser("~/CARLA_DISK/PythonAPI/carla"),
            os.path.expanduser("~/İndirilenler/PythonAPI/carla"),
        ]

        for p in possible_paths:
            if os.path.isdir(p) and p not in sys.path:
                sys.path.append(p)

        try:
            from agents.navigation.basic_agent import BasicAgent
            self.get_logger().info("BasicAgent import OK.")
            return BasicAgent
        except Exception as e:
            raise RuntimeError(f"BasicAgent import edilemedi. PythonAPI/carla/agents yolu yok veya hatalı: {e}")

    def configure_agent_ignore_rules(self):
        for method_name in ["ignore_traffic_lights", "ignore_stop_signs", "ignore_vehicles"]:
            try:
                if hasattr(self.agent, method_name):
                    getattr(self.agent, method_name)(True)
                    self.get_logger().info(f"BasicAgent {method_name}(True)")
            except Exception as e:
                self.get_logger().warning(f"{method_name} ayarlanamadı: {e}")

    def wait_for_ego(self):
        for _ in range(300):
            vehicles = self.world.get_actors().filter("vehicle.*")
            for vehicle in vehicles:
                if vehicle.attributes.get("role_name", "") == self.ego_role_name:
                    self.get_logger().info(f"Ego bulundu: id={vehicle.id}")
                    return vehicle
            time.sleep(0.2)

        raise RuntimeError("Ego vehicle bulunamadı.")

    def decision_cb(self, msg):
        try:
            data = json.loads(msg.data)

            # Off-lane person filter:
            # Kamera genişliği 960. center_x oranı 0.30-0.70 dışındaysa kişi şerit dışında kabul edilir.
            try:
                if str(data.get("decision", "")).upper() == "STOP" and "person" in str(data.get("reason", "")):
                    person = data.get("active_person")
                    if isinstance(person, dict):
                        cx = person.get("center_x")
                        bottom = person.get("bottom_ratio")

                        if cx is None:
                            bbox = person.get("bbox")
                            if isinstance(bbox, list) and len(bbox) >= 4:
                                cx = (float(bbox[0]) + float(bbox[2])) / 2.0

                        if cx is not None:
                            cx_ratio = float(cx) / 960.0
                            bottom_ok = True if bottom is None else float(bottom) >= 0.45
                            in_lane = 0.30 <= cx_ratio <= 0.70 and bottom_ok

                            if not in_lane:
                                old_reason = data.get("reason")
                                data["decision"] = "GO"
                                data["risk"] = "LOW"
                                data["target_speed"] = 0.8
                                data["reason"] = (
                                    f"route_offlane_person_filtered:"
                                    f"old={old_reason},cx={cx_ratio:.3f},bottom={bottom}"
                                )
                                data["person_risk"] = "offlane_filtered"
            except Exception as exc:
                self.get_logger().warning(f"offlane person filter hata: {exc}")

            self.latest_decision = data
            self.last_decision_time = time.time()

            self.update_forbidden_turn_from_decision(data)

        except Exception as exc:
            self.get_logger().warning(f"decision parse hatası: {exc}")

    def angle_norm_deg(self, angle):
        return (float(angle) + 180.0) % 360.0 - 180.0

    def classify_relative_turn_to_location(self, ego_tf, loc):
        try:
            ego_loc = ego_tf.location
            fwd = ego_tf.get_forward_vector()
            right = ego_tf.get_right_vector()

            vx = float(loc.x) - float(ego_loc.x)
            vy = float(loc.y) - float(ego_loc.y)

            forward_dot = vx * float(fwd.x) + vy * float(fwd.y)
            right_dot = vx * float(right.x) + vy * float(right.y)

            angle_deg = math.degrees(math.atan2(right_dot, max(0.001, forward_dot)))

            if angle_deg > 25.0:
                return "right", angle_deg
            if angle_deg < -25.0:
                return "left", angle_deg
            return "straight", angle_deg

        except Exception:
            return "unknown", 0.0

    def forbidden_turn_is_active(self):
        """
        Yasak dönüş isteği süre doldu diye kavşak üstünde unutulmamalı.

        Eski davranış:
          - saga_donulmez kırmızı ışıkta görülüyor
          - araç kırmızıda beklerken 12s hold süresi doluyor
          - yeşilde yasak unutulup ana hedefe sağdan gidilebiliyor

        Yeni davranış:
          - Detour hedefi varsa hedefe yaklaşana kadar aktif tut
          - Süre dolduysa ama detour hâlâ geçilmediyse süreyi küçük adımlarla uzat
        """
        now = time.time()

        if self.forbidden_turn_request is None:
            return False

        if self.forbidden_detour_target is not None:
            try:
                detour_loc = self.carla.Location(
                    x=float(self.forbidden_detour_target["carla_x"]),
                    y=float(self.forbidden_detour_target["carla_y"]),
                    z=float(self.forbidden_detour_target.get("carla_z", 0.2)),
                )
                d = self.distance_to_location(detour_loc)

                if d is not None and d <= 5.5:
                    self.clear_forbidden_turn(f"detour_reached:{d:.1f}m")
                    return False

                # Süre doldu ama detour geçilmediyse aktif tut.
                if now > self.forbidden_turn_until:
                    self.forbidden_turn_until = now + 2.0

                return True

            except Exception:
                # Detour hedefi parse edilemiyorsa süre kontrolüne düş.
                pass

        if now > self.forbidden_turn_until:
            self.clear_forbidden_turn("expired_no_detour")
            return False

        return True

    def clear_forbidden_turn(self, reason):
        if self.forbidden_turn_request is not None:
            self.get_logger().info(f"FORBIDDEN_TURN_CLEAR reason={reason}")

        self.forbidden_turn_request = None
        self.forbidden_turn_until = 0.0
        self.forbidden_detour_target = None
        self.last_forbidden_turn_key = None
        self.active_target_key = None

    def make_forbidden_turn_detour(self, request):
        """
        CARLA haritasında ego önündeki branch'leri dener ve yasak olmayan
        bir lokal hedef seçer. Bu BasicAgent destination'ı geçici olarak değiştirir.
        Böylece saga_donulmez varken sağ branch'e, sola_donulmez varken sol branch'e girmez.
        """
        try:
            forbidden = str(request.get("forbidden_turn", "")).lower().strip()
            sign_type = str(request.get("sign_type", "unknown"))

            ego_tf = self.ego.get_transform()
            ego_loc = ego_tf.location

            start_wp = self.map.get_waypoint(
                ego_loc,
                project_to_road=True,
                lane_type=self.carla.LaneType.Driving,
            )

            if start_wp is None:
                return None

            if forbidden == "right":
                blocked = {"right"}
                preference = {"straight": 0, "left": 1, "right": 99, "unknown": 50}
            elif forbidden == "left":
                blocked = {"left"}
                preference = {"straight": 0, "right": 1, "left": 99, "unknown": 50}
            elif forbidden in {"straight", "no_entry"}:
                blocked = {"straight"}
                preference = {"right": 0, "left": 0, "straight": 99, "unknown": 50}
            else:
                return None

            candidates = []
            step_m = 7.0
            frontier = [(start_wp, 0.0)]
            visited = set()

            for _depth in range(8):
                new_frontier = []

                for wp, dist_m in frontier:
                    try:
                        next_list = wp.next(step_m)
                    except Exception:
                        next_list = []

                    for nxt in next_list:
                        try:
                            key = (
                                int(getattr(nxt, "road_id", 0)),
                                int(getattr(nxt, "lane_id", 0)),
                                int(round(float(nxt.transform.location.x))),
                                int(round(float(nxt.transform.location.y))),
                            )
                        except Exception:
                            key = None

                        if key is not None and key in visited:
                            continue

                        if key is not None:
                            visited.add(key)

                        total_d = float(dist_m) + step_m
                        loc = nxt.transform.location
                        turn, angle = self.classify_relative_turn_to_location(ego_tf, loc)

                        if total_d >= 22.0:
                            if turn not in blocked:
                                pref = preference.get(turn, 50)
                                # Düz gitmek genelde en güvenli; çok keskin açıları sona at.
                                angle_penalty = abs(float(angle)) * 0.01
                                score = pref + angle_penalty + abs(total_d - 32.0) * 0.02
                                candidates.append((score, nxt, turn, angle, total_d))

                        if total_d <= 55.0:
                            new_frontier.append((nxt, total_d))

                frontier = new_frontier[:24]

            if not candidates:
                self.get_logger().warning(
                    f"FORBIDDEN_TURN_DETOUR_NOT_FOUND sign={sign_type} forbidden={forbidden}"
                )
                return None

            candidates.sort(key=lambda x: x[0])
            _score, best_wp, turn, angle, total_d = candidates[0]
            loc = best_wp.transform.location

            target = {
                "name": f"forbidden_detour_{sign_type}_{forbidden}_{turn}",
                "description": f"Temporary detour for {sign_type}; forbidden={forbidden}; selected={turn}",
                "carla_x": float(loc.x),
                "carla_y": float(loc.y),
                "carla_z": float(loc.z),
                "carla_yaw": float(best_wp.transform.rotation.yaw),
                "lat": float(loc.y),
                "lon": float(loc.x),
                "kind": "forbidden_turn_detour",
                "forbidden_turn": forbidden,
                "selected_turn": turn,
                "selected_angle_deg": round(float(angle), 2),
                "detour_distance_m": round(float(total_d), 2),
                "sign_type": sign_type,
            }

            self.get_logger().warning(
                "FORBIDDEN_TURN_DETOUR_SET "
                f"sign={sign_type} forbidden={forbidden} selected={turn} "
                f"angle={angle:.1f} dist={total_d:.1f} "
                f"dest=({loc.x:.2f},{loc.y:.2f},{loc.z:.2f})"
            )

            return target

        except Exception as exc:
            self.get_logger().warning(f"FORBIDDEN_TURN_DETOUR_FAILED: {exc}")
            return None

    def update_forbidden_turn_from_decision(self, data):
        req = data.get("route_replan_request")

        if not isinstance(req, dict) or not bool(req.get("active", False)):
            return

        forbidden = str(req.get("forbidden_turn", "")).lower().strip()
        if forbidden not in {"right", "left", "straight", "no_entry"}:
            return

        sign_type = str(req.get("sign_type", "unknown"))
        distance_m = req.get("distance_m", None)

        try:
            distance_key = round(float(distance_m), 1) if distance_m is not None else -1.0
        except Exception:
            distance_key = -1.0

        key = f"{sign_type}|{forbidden}|{distance_key}"

        now = time.time()
        hold_s = float(req.get("hold_seconds", 12.0) or 12.0)

        # Aynı isteği sürekli geliyorsa destination'ı her frame resetleme.
        if (
            self.last_forbidden_turn_key == key
            and self.forbidden_turn_request is not None
            and now < self.forbidden_turn_until
        ):
            self.forbidden_turn_until = max(self.forbidden_turn_until, now + hold_s)
            return

        detour = self.make_forbidden_turn_detour(req)

        self.forbidden_turn_request = dict(req)
        self.forbidden_turn_until = now + hold_s
        self.forbidden_detour_target = detour
        self.last_forbidden_turn_key = key

        # BasicAgent yeni detour hedefini hemen alsın.
        self.active_target_key = None

        if detour is None:
            self.get_logger().warning(
                f"FORBIDDEN_TURN_ACTIVE_BUT_NO_DETOUR sign={sign_type} forbidden={forbidden}"
            )

    def mission_cb(self, msg):
        try:
            self.latest_mission = json.loads(msg.data)
            self.last_mission_time = time.time()
        except Exception as exc:
            self.get_logger().warning(f"mission parse hatası: {exc}")

    def local_target_cb(self, msg):
        """
        GlobalRoutePlannerNode çıktısını RouteAgent hedef formatına çevirir.

        Gelen mesaj:
          /adas/planning/local_target

        Bu hedef, GeoJSON'dan gelen görev noktası değildir.
        Runtime planner'ın ürettiği yakın takip hedefidir.
        """
        try:
            data = json.loads(msg.data)

            x = data.get("x")
            y = data.get("y")
            z = data.get("z", 0.2)

            if x is None or y is None:
                return

            route_id = data.get("route_id")
            target_name = str(data.get("target_name", "planner_target"))
            road_id = data.get("road_id")
            lane_id = data.get("lane_id")

            local = dict(data)
            local["name"] = f"planner_local_{target_name}"
            local["description"] = "Runtime planner local target"
            local["carla_x"] = float(x)
            local["carla_y"] = float(y)
            local["carla_z"] = float(z)
            local["carla_yaw"] = float(data.get("yaw", 0.0))
            local["lat"] = float(y)
            local["lon"] = float(x)
            local["kind"] = "planner_local"
            key_res = max(0.5, float(self.planner_target_key_resolution_m))
            x_bucket = int(round(float(x) / key_res))
            y_bucket = int(round(float(y) / key_res))

            local["_planner_key"] = (
                f"planner|route={route_id}|target={target_name}|"
                f"xb={x_bucket}|yb={y_bucket}|res={key_res:.1f}|"
                f"road={road_id}|lane={lane_id}"
            )

            self.latest_local_target = local
            self.last_local_target_time = time.time()

        except Exception as exc:
            self.get_logger().warning(f"planner local_target parse hatası: {exc}")

    def collision_cb(self, msg):
        self.last_collision = msg.data
        self.collision_until = time.time() + self.collision_halt_s
        self.get_logger().warning(f"COLLISION HALT: {msg.data}")

    def lane_cb(self, msg):
        try:
            self.latest_lane = json.loads(msg.data)
            self.last_lane_time = time.time()
        except Exception as exc:
            self.get_logger().warning(f"lane assist parse hatası: {exc}")

    def apply_lane_assist_to_steer(self, basic_steer, target_speed):
        now = time.time()
        stage = self.get_stage()

        debug = {
            "enabled": bool(self.lane_assist_enabled),
            "used": False,
            "reason": "not_used",
            "basic_steer": round(float(basic_steer), 4),
            "final_steer": round(float(basic_steer), 4),
            "lane_confidence": None,
            "lane_steer": None,
            "lane_offset_norm": None,
            "blend": 0.0,
        }

        if not self.lane_assist_enabled:
            debug["reason"] = "disabled"
            self.current_lane_debug = debug
            return basic_steer

        if stage not in self.lane_allowed_stages:
            debug["reason"] = f"stage_not_allowed:{stage}"
            self.current_lane_debug = debug
            return basic_steer

        if target_speed <= 0.05:
            debug["reason"] = "target_speed_zero"
            self.current_lane_debug = debug
            return basic_steer

        if self.latest_lane is None or now - self.last_lane_time > self.lane_fresh_timeout_s:
            debug["reason"] = "lane_timeout"
            self.current_lane_debug = debug
            return basic_steer

        lane_detected = bool(self.latest_lane.get("lane_detected", False))
        conf = float(self.latest_lane.get("confidence", 0.0))
        lane_steer = float(self.latest_lane.get("lane_steer", 0.0))
        offset_norm = float(self.latest_lane.get("offset_norm", 0.0))

        debug["lane_confidence"] = round(conf, 3)
        debug["lane_steer"] = round(lane_steer, 4)
        debug["lane_offset_norm"] = round(offset_norm, 4)

        if not lane_detected:
            debug["reason"] = "lane_not_detected"
            self.current_lane_debug = debug
            return basic_steer

        if conf < self.lane_min_confidence:
            debug["reason"] = f"low_conf:{conf:.3f}"
            self.current_lane_debug = debug
            return basic_steer

        # Keskin dönüşte lane etkisini azalt. Düz yolda daha fazla hizalasın.
        if abs(basic_steer) >= self.lane_turn_steer_threshold:
            blend = self.lane_blend_turn
            debug["reason"] = "used_turn_low_blend"
        else:
            blend = self.lane_blend_straight
            debug["reason"] = "used_straight_blend"

        blend = self.clamp(blend, 0.0, 0.75)
        final_steer = (1.0 - blend) * basic_steer + blend * lane_steer
        final_steer = self.clamp(final_steer, -self.max_steer, self.max_steer)

        debug["used"] = True
        debug["blend"] = round(float(blend), 3)
        debug["final_steer"] = round(float(final_steer), 4)

        self.current_lane_debug = debug
        return final_steer

    def get_speed(self):
        v = self.ego.get_velocity()
        return math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z)

    def clamp(self, value, mn, mx):
        return max(mn, min(mx, float(value)))

    def mps_to_kmh(self, value):
        try:
            return float(value) * 3.6
        except Exception:
            return 0.0

    def kmh_to_mps(self, value):
        try:
            return float(value) / 3.6
        except Exception:
            return 0.0

    def apply_planner_speed_hint_cap(self, target_speed, reason):
        """
        Planner speed_hint eskiden sadece resolve_target_speed sonundaki normal dönüşte
        uygulanıyordu. Trafik ışığı guard içindeki erken return'ler bunu bypass ediyordu.
        Bu yüzden park yaklaşımında 0.75 m/s hedefinden bir anda 5.5 m/s hedefe zıplıyordu.

        Bu fonksiyon tick seviyesinde tekrar cap uygular; hiçbir erken return planner hızını aşamaz.
        """
        if not self.planner_speed_hint_enabled:
            return target_speed, reason

        planner_target = self.get_fresh_planner_target()
        if planner_target is None:
            return target_speed, reason

        speed_hint = planner_target.get("speed_hint_mps")

        if planner_target.get("speed_hint_kmh") is not None:
            try:
                speed_hint = self.kmh_to_mps(planner_target.get("speed_hint_kmh"))
            except Exception:
                pass

        if speed_hint is None:
            return target_speed, reason

        try:
            speed_hint = float(speed_hint)
            target_speed = float(target_speed)
        except Exception:
            return target_speed, reason

        capped = min(target_speed, speed_hint)

        if capped < target_speed - 0.01 and "planner_speed_hint" not in str(reason):
            reason = f"{reason}|planner_speed_hint:{speed_hint * 3.6:.1f}kmh/{speed_hint:.2f}mps"

        return capped, reason

    def apply_target_speed_smoothing(self, target_speed, reason):
        """
        Hedef hızın ani yükselmesini/yumuşak düşmesini sınırlar.
        STOP/PARKING gibi target=0 durumları güvenlik için anında uygulanır.
        """
        target_speed = float(target_speed)

        if not self.target_speed_smoothing_enabled:
            self.last_smoothed_target_speed_mps = target_speed
            self.last_smoothed_target_time = time.time()
            return target_speed, reason

        now = time.time()

        if target_speed <= 0.01:
            self.last_smoothed_target_speed_mps = 0.0
            self.last_smoothed_target_time = now
            return 0.0, reason

        if self.last_smoothed_target_speed_mps is None:
            self.last_smoothed_target_speed_mps = target_speed
            self.last_smoothed_target_time = now
            return target_speed, reason

        dt = now - float(self.last_smoothed_target_time or now)
        dt = self.clamp(dt, 0.02, 0.20)

        prev = float(self.last_smoothed_target_speed_mps)

        if target_speed > prev:
            max_step = max(0.05, float(self.target_speed_accel_limit_mps2) * dt)
            smoothed = min(target_speed, prev + max_step)
        else:
            max_step = max(0.08, float(self.target_speed_decel_limit_mps2) * dt)
            smoothed = max(target_speed, prev - max_step)

        self.last_smoothed_target_speed_mps = smoothed
        self.last_smoothed_target_time = now

        if abs(smoothed - target_speed) > 0.03:
            reason = f"{reason}|target_smooth:{target_speed:.2f}->{smoothed:.2f}"

        return smoothed, reason

    def get_stage(self):
        if not self.latest_mission:
            return None
        return self.latest_mission.get("stage")

    def get_fresh_planner_target(self):
        if not self.use_planner_local_target:
            return None

        if self.latest_local_target is None:
            return None

        if time.time() - self.last_local_target_time > self.planner_fresh_timeout_s:
            return None

        return self.latest_local_target

    def get_mission_objective_target(self):
        if not self.latest_mission:
            return None

        target = self.latest_mission.get("objective_target")
        if isinstance(target, dict):
            return target

        target = self.latest_mission.get("target")
        if isinstance(target, dict):
            return target

        return None

    def get_target(self):
        """
        BasicAgent destination seçimi.

        Normalde:
          - BasicAgent destination = mission objective
          - Planner local target = speed_hint/debug

        Yasak dönüş/girilmez levhası aktifse:
          - BasicAgent destination = geçici lokal detour hedefi
          - Detour geçilince ana mission objective'e geri dönülür.
        """
        if self.forbidden_turn_is_active():
            if self.forbidden_detour_target is not None:
                return self.forbidden_detour_target

        if self.use_planner_local_target and self.planner_local_target_as_destination:
            planner_target = self.get_fresh_planner_target()
            if planner_target is not None:
                return planner_target

        return self.get_mission_objective_target()

    def get_target_key(self):
        target = self.get_target()
        if not target or not self.latest_mission:
            return None

        planner_key = target.get("_planner_key")
        if planner_key and self.planner_local_target_as_destination:
            return str(planner_key)

        objective_index = self.latest_mission.get(
            "objective_index",
            self.latest_mission.get("route_index", self.latest_mission.get("task_index")),
        )

        objective_kind = self.latest_mission.get(
            "objective_kind",
            self.latest_mission.get("route_kind", ""),
        )

        try:
            carla_x = round(float(target.get("carla_x", target.get("lon", 0.0))), 3)
            carla_y = round(float(target.get("carla_y", target.get("lat", 0.0))), 3)
        except Exception:
            carla_x = target.get("carla_x", target.get("lon", 0.0))
            carla_y = target.get("carla_y", target.get("lat", 0.0))

        return (
            str(self.latest_mission.get("stage")) + "|" +
            str(objective_index) + "|" +
            str(objective_kind) + "|" +
            str(target.get("name")) + "|" +
            str(carla_x) + "|" +
            str(carla_y)
        )

    def mission_geo_to_carla_location_near_ego(self, target):
        """
        Town03 simülasyonunda mission dosyamız CARLA local x/y kullanıyor.
        Eski kod target lat/lon bilgisini CARLA geolocation sanıp dönüşüm yapıyordu.
        Bu da 10 milyon metre gibi saçma mesafelere ve yanlış BasicAgent hedefine yol açıyordu.

        Eğer target içinde carla_x/carla_y varsa direkt local CARLA Location döndür.
        Yoksa legacy gerçek GPS davranışına geri düş.
        """
        try:
            if target.get("carla_x") is not None and target.get("carla_y") is not None:
                x = float(target.get("carla_x"))
                y = float(target.get("carla_y"))
                z = target.get("carla_z", None)

                if z is None:
                    ego_z = self.ego.get_location().z
                    z = ego_z
                else:
                    z = float(z)

                return self.carla.Location(x=x, y=y, z=z + 0.2)
        except Exception as exc:
            self.get_logger().warning(f"carla_x/carla_y target parse hatası: {exc}")

        ego_loc = self.ego.get_location()

        base_geo = self.map.transform_to_geolocation(ego_loc)

        geo_x = self.map.transform_to_geolocation(
            self.carla.Location(x=ego_loc.x + 1.0, y=ego_loc.y, z=ego_loc.z)
        )
        geo_y = self.map.transform_to_geolocation(
            self.carla.Location(x=ego_loc.x, y=ego_loc.y + 1.0, z=ego_loc.z)
        )

        lat0 = float(base_geo.latitude)
        lon0 = float(base_geo.longitude)

        lat_dx = float(geo_x.latitude) - lat0
        lon_dx = float(geo_x.longitude) - lon0
        lat_dy = float(geo_y.latitude) - lat0
        lon_dy = float(geo_y.longitude) - lon0

        target_lat = float(target["lat"])
        target_lon = float(target["lon"])

        dlat = target_lat - lat0
        dlon = target_lon - lon0

        det = lat_dx * lon_dy - lat_dy * lon_dx

        if abs(det) < 1e-16:
            self.get_logger().warning("Geo inverse det çok küçük.")
            return ego_loc

        dx = (dlat * lon_dy - lat_dy * dlon) / det
        dy = (lat_dx * dlon - dlat * lon_dx) / det

        dx = self.clamp(dx, -500.0, 500.0)
        dy = self.clamp(dy, -500.0, 500.0)

        return self.carla.Location(x=ego_loc.x + dx, y=ego_loc.y + dy, z=ego_loc.z)


    def get_turn_direction_to_target(self, target):
        """
        Ego'dan hedefe göre kaba dönüş niyeti:
        - left  : hedef ego'nun solunda kalıyor
        - right : hedef ego'nun sağında kalıyor
        - straight: büyük yan sapma yok

        Bu sadece şerit/yaklaşım seçimi için kullanılır; asıl rotayı BasicAgent üretir.
        """
        try:
            raw_loc = self.mission_geo_to_carla_location_near_ego(target)
            ego_tf = self.ego.get_transform()
            ego_loc = ego_tf.location
            fwd = ego_tf.get_forward_vector()
            right = ego_tf.get_right_vector()

            vx = raw_loc.x - ego_loc.x
            vy = raw_loc.y - ego_loc.y

            forward_dot = vx * fwd.x + vy * fwd.y
            right_dot = vx * right.x + vy * right.y

            # Sağ pozitif, sol negatif.
            angle_deg = math.degrees(math.atan2(right_dot, max(0.001, forward_dot)))

            if angle_deg < -22.0:
                return "left", angle_deg
            if angle_deg > 22.0:
                return "right", angle_deg

            return "straight", angle_deg

        except Exception as exc:
            self.get_logger().warning(f"turn direction hesaplanamadı: {exc}", throttle_duration_sec=1.0)
            return "unknown", 0.0

    def get_same_direction_adjacent_lane(self, wp, turn_direction):
        """
        Mümkünse aynı yöndeki komşu şeridi seç.
        Sol dönüşte sol şerit, sağ dönüşte sağ şerit tercih edilir.
        """
        try:
            if wp is None:
                return None

            if turn_direction == "left":
                cand = wp.get_left_lane()
            elif turn_direction == "right":
                cand = wp.get_right_lane()
            else:
                return None

            if cand is None:
                return None

            if cand.lane_type != self.carla.LaneType.Driving:
                return None

            # CARLA'da aynı yöndeki lane'ler genelde aynı lane_id işaretindedir.
            try:
                if int(cand.lane_id) * int(wp.lane_id) <= 0:
                    return None
            except Exception:
                pass

            return cand

        except Exception:
            return None

    def shifted_location_from_waypoint(self, wp, lateral_shift_m):
        loc = wp.transform.location

        if abs(float(lateral_shift_m)) < 0.05:
            return self.carla.Location(x=loc.x, y=loc.y, z=loc.z + 0.2)

        right_vec = wp.transform.get_right_vector()
        shifted_x = loc.x + right_vec.x * float(lateral_shift_m)
        shifted_y = loc.y + right_vec.y * float(lateral_shift_m)

        # Shift sonrası tekrar yola projekte et ki off-road hedef verilmesin.
        shifted = self.carla.Location(x=shifted_x, y=shifted_y, z=loc.z + 0.2)

        try:
            shifted_wp = self.map.get_waypoint(
                shifted,
                project_to_road=True,
                lane_type=self.carla.LaneType.Driving,
            )

            if shifted_wp is not None:
                sloc = shifted_wp.transform.location
                return self.carla.Location(x=sloc.x, y=sloc.y, z=sloc.z + 0.2)

        except Exception:
            pass

        return shifted

    def destination_from_target(self, target):
        """
        SAFE_LANE_CENTER_FIX:
        Town03'te target adında 'sag/right/park' geçince yapılan otomatik sağ şerit/sağ shift
        aracı kaldırım, tabela, direk ve bina tarafına fazla yaklaştırıyordu.

        Bu yüzden hedefi artık doğrudan CARLA'nın sürüş şeridi merkezine projekte ediyoruz.
        Park hedefinde bile ekstra sağa shift yok; park noktası mission dosyasında zaten belirleniyor.
        """
        raw_loc = self.mission_geo_to_carla_location_near_ego(target)

        wp = self.map.get_waypoint(
            raw_loc,
            project_to_road=True,
            lane_type=self.carla.LaneType.Driving,
        )

        stage = str(self.get_stage() or "")
        target_name = str(target.get("name", "")).lower()

        if wp is None:
            self.get_logger().warning("Target waypoint bulunamadı, raw location kullanılacak.")
            return raw_loc

        loc = wp.transform.location
        dest = self.carla.Location(x=loc.x, y=loc.y, z=loc.z + 0.2)

        self.get_logger().info(
            f"Destination lane approach SAFE_CENTER: target={target.get('name')} "
            f"stage={stage} shift=0.00 reason=no_auto_right_shift "
            f"dest=({dest.x:.2f},{dest.y:.2f},{dest.z:.2f})",
            throttle_duration_sec=0.5,
        )

        return dest

    def is_planner_local_target(self, target):
        if not isinstance(target, dict):
            return False

        if target.get("_planner_key"):
            return True

        if str(target.get("kind", "")).lower() == "planner_local":
            return True

        if str(target.get("name", "")).startswith("planner_local_"):
            return True

        return False

    def distance_to_location(self, loc):
        try:
            ego_loc = self.ego.get_location()
            return math.hypot(float(ego_loc.x) - float(loc.x), float(ego_loc.y) - float(loc.y))
        except Exception:
            return None

    def should_hold_current_destination(self, target, key, new_dest):
        """
        Planner local target 10 Hz akıyor. Eski davranışta her birkaç metrede
        BasicAgent.set_destination tekrar çalışıyordu. Bu, BasicAgent'ın iç route
        planını sürekli sıfırladığı için araçta tekleme/silkelenme yapıyordu.

        Yeni davranış:
          - route_id değişirse hemen güncelle.
          - aktif destination'a yeterince yaklaştıysa güncelle.
          - yeni destination çok ilerideyse ve minimum süre geçtiyse güncelle.
          - aksi halde mevcut BasicAgent hedefini tut.
        """
        if not self.planner_destination_hold_enabled:
            return False

        if not self.is_planner_local_target(target):
            return False

        if self.active_target_key is None or self.active_destination is None:
            return False

        now = time.time()

        try:
            route_id = target.get("route_id")
        except Exception:
            route_id = None

        if route_id is not None and self.active_planner_route_id is not None:
            if route_id != self.active_planner_route_id:
                return False

        active_dist = self.distance_to_location(self.active_destination)
        if active_dist is None:
            return False

        if active_dist <= self.planner_destination_reached_m:
            return False

        try:
            new_delta = math.hypot(
                float(new_dest.x) - float(self.active_destination.x),
                float(new_dest.y) - float(self.active_destination.y),
            )
        except Exception:
            new_delta = 999.0

        elapsed = now - float(self.last_agent_destination_set_time or 0.0)

        if (
            elapsed >= self.planner_destination_update_min_interval_s
            and new_delta >= self.planner_destination_update_min_distance_m
        ):
            return False

        self.route_status = (
            f"planner_destination_hold:"
            f"active_dist={active_dist:.1f},new_delta={new_delta:.1f},elapsed={elapsed:.1f}"
        )
        return True

    def set_agent_destination_if_needed(self):
        target = self.get_target()
        key = self.get_target_key()

        if target is None or key is None:
            self.route_status = "mission_target_missing"
            return False

        dest = self.destination_from_target(target)

        if key == self.active_target_key:
            return True

        if self.should_hold_current_destination(target, key, dest):
            return True

        start = self.ego.get_location()

        try:
            self.agent.set_destination(dest)
        except TypeError:
            self.agent.set_destination(dest, start_location=start)
        except Exception:
            try:
                self.agent.set_destination(start, dest)
            except Exception as e:
                self.route_status = f"set_destination_failed:{e}"
                self.get_logger().error(self.route_status)
                return False

        self.active_target_key = key
        self.active_destination = dest
        self.last_agent_destination_set_time = time.time()

        if self.is_planner_local_target(target):
            self.active_planner_route_id = target.get("route_id")

        self.route_status = f"basic_agent_route_to:{target.get('name')}"

        self.get_logger().info(
            f"BasicAgent destination set: stage={self.get_stage()} "
            f"target={target.get('name')} dest=({dest.x:.2f},{dest.y:.2f},{dest.z:.2f})"
        )

        return True

    def hard_stop_control(self):
        control = self.carla.VehicleControl()
        control.throttle = 0.0
        control.brake = 1.0
        control.steer = 0.0
        control.hand_brake = False
        control.manual_gear_shift = False
        return control

    def smooth_stop_control(self, reason=""):
        """
        Normal STOP durumunda brake=1.0 aracı zıplatıyor.
        Collision gibi acil durumda hard_stop ayrı kalıyor.
        Trafik ışığı / karar duruşunda hızla orantılı daha kontrollü fren yapıyoruz.
        """
        speed = self.get_speed()

        control = self.carla.VehicleControl()
        control.throttle = 0.0
        control.steer = 0.0
        control.hand_brake = False
        control.manual_gear_shift = False

        if speed < 0.25:
            control.brake = 1.0
            return control

        # 18 km/h civarında ~0.60, düşük hızda ~0.28.
        brake = 0.22 + 0.075 * float(speed)
        control.brake = self.clamp(brake, 0.25, 0.65)
        return control

    def apply_forbidden_turn_steer_guard(self, control):
        """
        BasicAgent bazen detour destination verilse bile kavşakta eski rotaya doğru
        sağa/sola kırabiliyor. Yasak dönüş aktifken fiziksel direksiyon emniyeti uygula.

        CARLA'da pozitif steer sağa, negatif steer sola döner.
        """
        try:
            if self.forbidden_turn_request is None:
                return ""

            if not self.forbidden_turn_is_active():
                return ""

            forbidden = str(self.forbidden_turn_request.get("forbidden_turn", "")).lower().strip()
            sign_type = str(self.forbidden_turn_request.get("sign_type", "unknown"))

            if forbidden == "right" and float(control.steer) > 0.03:
                old = float(control.steer)
                control.steer = min(0.02, old)
                return f"forbidden_right_steer_guard:{sign_type}:{old:.2f}->0.02"

            if forbidden == "left" and float(control.steer) < -0.03:
                old = float(control.steer)
                control.steer = max(-0.02, old)
                return f"forbidden_left_steer_guard:{sign_type}:{old:.2f}->-0.02"

            # straight/no_entry için direksiyonu fiziksel olarak zorlamıyoruz.
            # Bu iş detour destination ile çözülmeli. Aksi halde kavşakta/ışıkta
            # yanlış pozitif "girişi olmayan yol" algısı aracı sağa itebilir.
            return ""

        except Exception as exc:
            return f"forbidden_steer_guard_error:{exc}"

    def normalize_carla_tl_state(self, raw_state):
        if raw_state is None:
            return "unknown"

        name = getattr(raw_state, "name", None)
        if name is None:
            name = str(raw_state)

        name = str(name).split(".")[-1].strip().lower()

        if name in {"red", "trafficlightstatered"}:
            return "red"
        if name in {"yellow", "amber", "trafficlightstateyellow"}:
            return "yellow"
        if name in {"green", "trafficlightstategreen"}:
            return "green"

        return name or "unknown"

    def get_tl_actor_state(self, tl_actor):
        try:
            return self.normalize_carla_tl_state(tl_actor.get_state())
        except Exception:
            return "unknown"

    def get_tl_actor_candidate_points(self, tl_actor):
        """
        CARLA traffic light için uygulanabilir durma noktalarını döndürür.

        Öncelik:
          1) get_stop_waypoints(): en doğru stop-line noktaları.
          2) trigger_volume world point.
          3) actor transform location.
        """
        points = []

        try:
            if hasattr(tl_actor, "get_stop_waypoints"):
                wps = tl_actor.get_stop_waypoints() or []
                for wp in wps:
                    try:
                        points.append((wp.transform.location, wp))
                    except Exception:
                        pass
        except Exception:
            pass

        if points:
            return points

        try:
            trigger = getattr(tl_actor, "trigger_volume", None)
            if trigger is not None:
                tf = tl_actor.get_transform()
                loc = tf.transform(trigger.location)
                wp = None
                try:
                    wp = self.map.get_waypoint(
                        loc,
                        project_to_road=True,
                        lane_type=self.carla.LaneType.Driving,
                    )
                except Exception:
                    wp = None
                points.append((loc, wp))
        except Exception:
            pass

        if points:
            return points

        try:
            loc = tl_actor.get_transform().location
            wp = None
            try:
                wp = self.map.get_waypoint(
                    loc,
                    project_to_road=True,
                    lane_type=self.carla.LaneType.Driving,
                )
            except Exception:
                wp = None
            points.append((loc, wp))
        except Exception:
            pass

        return points

    def get_forward_carla_tl_lookahead(self):
        """
        Ego trigger alanına girmeden önce öndeki gerçek CARLA trafik ışığını bulur.

        False-positive engelleri:
          - sadece ego'nun önündeki noktalar
          - lateral mesafe sınırı
          - görüş açısı sınırı
          - stop waypoint yönü ego ile kabaca aynı yön
          - dinamik mesafe: hız arttıkça bakış mesafesi artar, dururken çok uzağa bakmaz
        """
        out = {
            "at_light": False,
            "state": "unknown",
            "id": None,
            "source": "lookahead_none",
            "distance_m": None,
            "forward_m": None,
            "lateral_m": None,
            "angle_deg": None,
            "same_dir_dot": None,
        }

        if not self.carla_tl_lookahead_enabled:
            out["source"] = "lookahead_disabled"
            return out

        try:
            ego_tf = self.ego.get_transform()
            ego_loc = ego_tf.location
            ego_fwd = ego_tf.get_forward_vector()
            ego_right = ego_tf.get_right_vector()

            speed = self.get_speed()
            # 30 km/h civarında yaklaşık 45-47 m ileri bakar.
            dynamic_horizon = self.clamp(
                float(speed) * 4.2 + 12.0,
                22.0,
                float(self.carla_tl_lookahead_distance_m),
            )

            min_forward = max(0.0, float(self.carla_tl_lookahead_min_distance_m))
            base_lateral_limit = max(2.0, float(self.carla_tl_lookahead_lateral_m))
            max_angle = max(5.0, float(self.carla_tl_lookahead_fov_deg))
            min_same_dir_dot = float(self.carla_tl_lookahead_same_dir_dot)

            best = None

            for tl in self.world.get_actors().filter("traffic.traffic_light*"):
                state = self.get_tl_actor_state(tl)
                if state not in {"red", "yellow", "green"}:
                    continue

                for loc, wp in self.get_tl_actor_candidate_points(tl):
                    try:
                        dx = float(loc.x) - float(ego_loc.x)
                        dy = float(loc.y) - float(ego_loc.y)

                        forward = dx * float(ego_fwd.x) + dy * float(ego_fwd.y)
                        lateral = dx * float(ego_right.x) + dy * float(ego_right.y)

                        if forward < min_forward or forward > dynamic_horizon:
                            continue

                        lateral_limit = base_lateral_limit
                        same_dir_dot = None

                        if wp is not None:
                            try:
                                lateral_limit = max(
                                    lateral_limit,
                                    min(10.0, float(getattr(wp, "lane_width", 3.5)) * 1.7),
                                )
                            except Exception:
                                pass

                            try:
                                wp_fwd = wp.transform.get_forward_vector()
                                same_dir_dot = (
                                    float(ego_fwd.x) * float(wp_fwd.x)
                                    + float(ego_fwd.y) * float(wp_fwd.y)
                                )
                                if same_dir_dot < min_same_dir_dot:
                                    continue
                            except Exception:
                                pass

                        if abs(lateral) > lateral_limit:
                            continue

                        angle = abs(math.degrees(math.atan2(lateral, max(0.001, forward))))
                        if angle > max_angle:
                            continue

                        # Kırmızı/sarıyı biraz öne al, yeşil sadece release için yardımcı.
                        state_bonus = 0.0
                        if state == "red":
                            state_bonus = -4.0
                        elif state == "yellow":
                            state_bonus = -2.0

                        score = (
                            float(forward)
                            + abs(float(lateral)) * 2.2
                            + float(angle) * 0.12
                            + state_bonus
                        )

                        cand = {
                            "at_light": True,
                            "state": state,
                            "id": getattr(tl, "id", None),
                            "source": "lookahead",
                            "distance_m": round(math.hypot(dx, dy), 2),
                            "forward_m": round(float(forward), 2),
                            "lateral_m": round(float(lateral), 2),
                            "angle_deg": round(float(angle), 1),
                            "same_dir_dot": round(float(same_dir_dot), 3)
                            if same_dir_dot is not None else None,
                            "horizon_m": round(float(dynamic_horizon), 2),
                        }

                        if best is None or score < best[0]:
                            best = (score, cand)

                    except Exception:
                        continue

            if best is not None:
                return best[1]

        except Exception as exc:
            out["source"] = f"lookahead_error:{exc}"
            try:
                self.get_logger().warning(f"CARLA TL lookahead hata: {exc}", throttle_duration_sec=1.0)
            except Exception:
                pass

        return out

    def get_carla_tl_guard_state(self):
        out = {
            "at_light": False,
            "state": "unknown",
            "id": None,
            "source": "direct_none",
            "distance_m": None,
            "forward_m": None,
            "lateral_m": None,
        }

        try:
            at_light = False
            try:
                at_light = bool(self.ego.is_at_traffic_light())
            except Exception:
                at_light = False

            tl_actor = None
            try:
                tl_actor = self.ego.get_traffic_light()
            except Exception:
                tl_actor = None

            raw_state = None

            if tl_actor is not None:
                out["id"] = getattr(tl_actor, "id", None)
                out["source"] = "direct_actor"
                try:
                    raw_state = tl_actor.get_state()
                except Exception:
                    raw_state = None

            if raw_state is None:
                try:
                    raw_state = self.ego.get_traffic_light_state()
                    if raw_state is not None:
                        out["source"] = "direct_ego_state"
                except Exception:
                    raw_state = None

            out["at_light"] = bool(at_light or tl_actor is not None)
            out["state"] = self.normalize_carla_tl_state(raw_state)

            # Direct CARLA bilgisi geçerliyse onu en güvenilir kaynak say.
            if out["at_light"] and out["state"] in {"red", "yellow", "green"}:
                self.last_carla_tl_guard_debug = dict(out)
                return out

            # Direct trigger henüz yoksa öndeki ışığı actor lookahead ile ara.
            lookahead = self.get_forward_carla_tl_lookahead()
            if lookahead.get("at_light") and lookahead.get("state") in {"red", "yellow", "green"}:
                self.last_carla_tl_guard_debug = dict(lookahead)
                return lookahead

            # Debug için direct başarısızsa lookahead sonucunu da taşı.
            out["lookahead_source"] = lookahead.get("source")
            out["lookahead_state"] = lookahead.get("state")
            self.last_carla_tl_guard_debug = dict(out)

        except Exception as exc:
            out["source"] = f"direct_error:{exc}"
            self.last_carla_tl_guard_debug = dict(out)
            self.get_logger().warning(f"CARLA TL guard okunamadı: {exc}", throttle_duration_sec=1.0)

        return out

    def is_traffic_light_stop_reason(self, reason):
        r = str(reason or "").lower()
        return (
            "traffic_light" in r
            or "red_light" in r
            or "yellow_light" in r
            or "tl_" in r
        )

    def resolve_target_speed(self):
        now = time.time()

        if self.latest_mission is None or now - self.last_mission_time > 3.0:
            return 0.0, "mission_missing_or_timeout"

        stage = str(self.latest_mission.get("stage", "UNKNOWN"))
        must_stop = bool(self.latest_mission.get("must_stop", False))
        distance_to_target = self.latest_mission.get("distance_to_target_m", None)

        if stage in {"COMPLETED", "FAILED"}:
            return 0.0, f"mission_{stage.lower()}"

        if self.mission_stop_override and must_stop:
            return 0.0, f"mission_stop_stage:{stage}"

        if stage == "PARKING":
            return self.parking_speed_mps, "parking_slow"

        if (
            self.forbidden_turn_request is not None
            and time.time() < self.forbidden_turn_until
            and self.forbidden_detour_target is None
        ):
            return 0.0, f"forbidden_turn_no_safe_detour:{self.forbidden_turn_request.get('sign_type')}"

        if False and self.ignore_decision_for_mission_test:
            target_speed = self.go_speed_mps
        else:
            if now - self.last_decision_time > 2.0:
                return 0.0, "decision_timeout"

            decision = str(self.latest_decision.get("decision", "STOP")).upper()
            reason = str(self.latest_decision.get("reason", "unknown"))

            # DECISION_SAFE_STOP_FINAL:
            # /adas/decision_safe STOP kararı finaldir; AMA trafik ışığı STOP'u
            # route_agent içindeki CARLA ışık state'i ile güvenli şekilde release edilebilir.
            #
            # Neden?
            # - Kırmızıda geçmeyi engellemek için STOP'u ezdirmemek lazım.
            # - Ama yeşilde kalkabilmek için traffic_light_red_gate sonsuza kadar
            #   kör final olmamalı.
            tl_reason_for_stop = self.is_traffic_light_stop_reason(reason)

            if decision == "STOP" and not tl_reason_for_stop:
                return 0.0, f"decision_safe_stop:{reason}"

            # CARLA_TL_GUARD_FIX:
            # Vision red yanlış/stale kalırsa CARLA state ile şartname davranışını koru.
            if self.carla_tl_override_enabled:
                tl_guard = self.get_carla_tl_guard_state()
                at_tl = bool(tl_guard.get("at_light", False))
                tl_state = str(tl_guard.get("state", "unknown")).lower()
                tl_reason = self.is_traffic_light_stop_reason(reason)

                now2 = time.time()

                # Işıktan çıkınca kısa süre yeni red tespitlerini yut.
                if self.last_carla_tl_at_light and not at_tl:
                    self.post_tl_ignore_until = now2 + self.post_tl_ignore_s

                # Kırmızı/sarıdan yeşile döndüyse kalkış boost'u.
                if self.last_carla_tl_state in {"red", "yellow"} and tl_state == "green":
                    self.green_release_until = now2 + self.green_release_boost_s
                    self.post_tl_ignore_until = now2 + self.post_tl_ignore_s

                self.last_carla_tl_state = tl_state
                self.last_carla_tl_at_light = at_tl

                if at_tl and tl_state == "red":
                    return 0.0, (
                        f"carla_tl_red:{tl_guard.get('source', 'unknown')}:"
                        f"d={tl_guard.get('forward_m', tl_guard.get('distance_m'))}"
                    )

                if at_tl and tl_state == "yellow":
                    return min(self.slow_speed_mps, 0.60), (
                        f"carla_tl_yellow:{tl_guard.get('source', 'unknown')}:"
                        f"d={tl_guard.get('forward_m', tl_guard.get('distance_m'))}"
                    )

                if at_tl and tl_state == "green":
                    if decision == "STOP" and tl_reason:
                        # CARLA ego ışığı green ise vision red artık override edilir.
                        # Full-stop şartı aracı 0.8 m/s üstünde tekrar 0'a çekip
                        # gıdım gıdım döngüye sokuyordu.
                        self.tl_green_override_until = now2 + max(3.0, float(self.green_release_boost_s))
                        self.post_tl_ignore_until = max(
                            self.post_tl_ignore_until,
                            now2 + float(self.post_tl_ignore_s),
                        )
                        return self.clamp(
                            max(self.green_release_speed_mps, self.go_speed_mps),
                            0.0,
                            self.max_speed_mps,
                        ), (
                            f"carla_tl_green_release:{tl_guard.get('source', 'unknown')}:"
                            f"d={tl_guard.get('forward_m', tl_guard.get('distance_m'))}"
                        )

                if now2 < self.post_tl_ignore_until and decision == "STOP" and tl_reason:
                    return self.clamp(
                        max(self.green_release_speed_mps, self.go_speed_mps),
                        0.0,
                        self.max_speed_mps,
                    ), "post_tl_pass_ignore_vision_red"

                if (
                    self.ignore_vision_red_when_carla_not_red
                    and decision == "STOP"
                    and tl_reason
                    and tl_state != "red"
                ):
                    # Sadece CARLA green iken vision red'i yok say.
                    # unknown/off durumda güvenli tarafta kal.
                    if tl_state == "green" or now2 < self.tl_green_override_until:
                        self.tl_green_override_until = now2 + max(3.0, float(self.green_release_boost_s))
                        self.post_tl_ignore_until = max(
                            self.post_tl_ignore_until,
                            now2 + float(self.post_tl_ignore_s),
                        )
                        return self.clamp(
                            max(self.green_release_speed_mps, self.go_speed_mps),
                            0.0,
                            self.max_speed_mps,
                        ), f"ignore_vision_red_carla_{tl_state}"

                    return 0.0, f"traffic_light_stop_wait_carla_{tl_state}_not_green"

            if decision == "SLOW":
                return self.slow_speed_mps, f"decision_slow:{reason}"

            try:
                if self.latest_decision.get("target_speed_kmh") is not None:
                    target_speed = self.kmh_to_mps(self.latest_decision.get("target_speed_kmh"))
                    reason = f"{reason}|decision_speed_kmh:{float(self.latest_decision.get('target_speed_kmh')):.1f}"
                else:
                    target_speed = float(self.latest_decision.get("target_speed", self.go_speed_mps))
            except Exception:
                target_speed = self.go_speed_mps

        # SMOOTH_APPROACH_FIX:
        # Eski davranış: hedefe 8m kala hedef hız bir anda 0.55'e düşüyordu.
        # Bu da 1.7-1.9 m/s giderken ani fren gibi görünüyordu.
        # Yeni davranış: kademeli yaklaş, sadece çok yakında iyice yavaşla.
        if distance_to_target is not None:
            try:
                d = float(distance_to_target)

                if stage in {"GO_TO_PARK", "PARKING"}:
                    if d < 3.0:
                        target_speed = min(target_speed, 0.45)
                    elif d < 5.0:
                        target_speed = min(target_speed, 0.75)
                    elif d < 8.0:
                        target_speed = min(target_speed, 1.15)
                else:
                    if d < 3.0:
                        target_speed = min(target_speed, 0.55)
                    elif d < 6.0:
                        target_speed = min(target_speed, 1.00)

            except Exception:
                pass

        if self.planner_speed_hint_enabled:
            planner_target = self.get_fresh_planner_target()
            if planner_target is not None:
                speed_hint = planner_target.get("speed_hint_mps")
                if planner_target.get("speed_hint_kmh") is not None:
                    try:
                        speed_hint = self.kmh_to_mps(planner_target.get("speed_hint_kmh"))
                    except Exception:
                        pass

                if speed_hint is not None:
                    try:
                        speed_hint = float(speed_hint)
                        target_speed = min(float(target_speed), speed_hint)
                        reason = f"{reason}|planner_speed_hint:{self.mps_to_kmh(speed_hint):.1f}kmh/{speed_hint:.2f}mps"
                    except Exception:
                        pass

        return self.clamp(target_speed, 0.0, self.max_speed_mps), reason

    def tick(self):
        target_speed, reason = self.resolve_target_speed()

        # GOREV2_SIGN_CRASH_FIX:
        # Gorev 2'den çıktıktan hemen sonra sağdaki tabelaya/kaldırıma bindirmemek için
        # sadece via_alt_yol_1 geçişinde hızı düşürüyoruz. Rotanın geri kalanı etkilenmez.
        try:
            target = self.get_target() or {}
            target_name = str(target.get("name", "")).lower()
            stage = str(self.get_stage() or "")
            if stage == "GO_TO_TASK" and target_name == "via_alt_yol_1" and target_speed > 3.0:
                target_speed = 3.0
                reason = f"{reason}|gorev2_exit_speed_cap"
        except Exception:
            pass

        target_speed, reason = self.apply_planner_speed_hint_cap(target_speed, reason)
        target_speed, reason = self.apply_target_speed_smoothing(target_speed, reason)

        current_speed = self.get_speed()

        if time.time() < self.collision_until:
            control = self.hard_stop_control()
            reason = "collision_halt"
            target_speed = 0.0
        elif target_speed <= 0.01:
            control = self.smooth_stop_control(reason)
        else:
            ok = self.set_agent_destination_if_needed()
            if not ok:
                control = self.hard_stop_control()
                reason = "route_missing_stop"
                target_speed = 0.0
            else:
                try:
                    self.agent.set_target_speed(target_speed * 3.6)
                except Exception:
                    pass

                try:
                    control = self.agent.run_step(debug=False)
                except TypeError:
                    control = self.agent.run_step()

                basic_steer = self.clamp(control.steer, -self.max_steer, self.max_steer)
                control.steer = self.apply_lane_assist_to_steer(basic_steer, target_speed)

                forbidden_steer_reason = self.apply_forbidden_turn_steer_guard(control)
                if forbidden_steer_reason:
                    reason = f"{reason}|{forbidden_steer_reason}"

                # SMOOTH_LONGITUDINAL_FIX:
                # BasicAgent steer iyi ama düşük hızda gaz/fren zıplatıyor.
                # Bu yüzden direksiyon BasicAgent'ten, throttle/brake yumuşak hız kontrolünden geliyor.
                if not hasattr(self, "last_throttle_cmd"):
                    self.last_throttle_cmd = 0.0
                if not hasattr(self, "last_brake_cmd"):
                    self.last_brake_cmd = 0.0

                speed_error = float(target_speed) - float(current_speed)
                overspeed = float(current_speed) - float(target_speed)

                desired_throttle = 0.0
                desired_brake = 0.0

                if speed_error > 0.20:
                    desired_throttle = 0.22 + 0.42 * speed_error
                    desired_throttle = self.clamp(desired_throttle, 0.20, 0.90)
                    desired_brake = 0.0
                elif overspeed <= 0.95:
                    desired_throttle = 0.018 if current_speed < target_speed else 0.0
                    desired_brake = 0.0
                else:
                    desired_throttle = 0.0
                    desired_brake = self.clamp(0.05 * (overspeed - 0.95), 0.0, 0.035)

                def _slew(cur, dst, step):
                    cur = float(cur)
                    dst = float(dst)
                    step = abs(float(step))
                    if dst > cur:
                        return min(dst, cur + step)
                    if dst < cur:
                        return max(dst, cur - step)
                    return cur

                throttle_cmd = _slew(self.last_throttle_cmd, desired_throttle, 0.160)
                brake_cmd = _slew(self.last_brake_cmd, desired_brake, 0.018)

                if brake_cmd > 0.001:
                    throttle_cmd = 0.0

                self.last_throttle_cmd = throttle_cmd
                self.last_brake_cmd = brake_cmd

                control.throttle = self.clamp(throttle_cmd, 0.0, 0.90)
                control.brake = self.clamp(brake_cmd, 0.0, 0.035)
                control.hand_brake = False
                control.manual_gear_shift = False

        # HARD SAFETY CLAMP: araç kontrolden çıkmasın diye hız/gaz sınırı
        try:
            control.throttle = self.clamp(control.throttle, 0.0, 0.90)
            control.steer = self.clamp(control.steer, -self.max_steer, self.max_steer)
        except Exception:
            pass

        self.ego.apply_control(control)

        target = self.get_target() or {}
        mission_dist = self.latest_mission.get("distance_to_target_m") if self.latest_mission else None

        payload = {
            "stamp": time.time(),
            "mission_stage": self.get_stage(),
            "task_index": self.latest_mission.get("task_index") if self.latest_mission else None,
            "target_name": target.get("name"),
            "target_is_planner_local": self.is_planner_local_target(target),
            "planner_local_as_destination": self.planner_local_target_as_destination,
            "distance_to_target_m": mission_dist,
            "target_speed_mps": round(target_speed, 3),
            "target_speed_kmh": round(self.mps_to_kmh(target_speed), 1),
            "current_speed_mps": round(current_speed, 3),
            "current_speed_kmh": round(self.mps_to_kmh(current_speed), 1),
            "throttle": round(control.throttle, 3),
            "brake": round(control.brake, 3),
            "steer": round(control.steer, 3),
            "route_status": self.route_status,
            "forbidden_turn_active": self.forbidden_turn_is_active(),
            "forbidden_turn_request": self.forbidden_turn_request,
            "forbidden_detour_target": self.forbidden_detour_target,
            "planner_enabled": self.use_planner_local_target,
            "planner_target_fresh": self.get_fresh_planner_target() is not None,
            "planner_target_age_s": round(time.time() - self.last_local_target_time, 3)
            if self.latest_local_target is not None else None,
            "planner_route_id": self.latest_local_target.get("route_id")
            if isinstance(self.latest_local_target, dict) else None,
            "carla_tl_guard": self.last_carla_tl_guard_debug,
            "lane": self.current_lane_debug,
            "reason": reason,
        }

        msg = String()
        msg.data = json.dumps(payload, ensure_ascii=False)
        self.debug_pub.publish(msg)

        self.get_logger().info(
            f"[TEKNOFEST ROUTE] stage={payload['mission_stage']} "
            f"target_name={payload['target_name']} "
            f"dist={payload['distance_to_target_m']} "
            f"target={target_speed:.2f}mps/{self.mps_to_kmh(target_speed):.1f}kmh "
            f"speed={current_speed:.2f}mps/{self.mps_to_kmh(current_speed):.1f}kmh "
            f"throttle={control.throttle:.2f} brake={control.brake:.2f} "
            f"steer={control.steer:.2f} lane={self.current_lane_debug.get('reason')} route={self.route_status} "
            f"reason={reason}",
            throttle_duration_sec=0.5,
        )


def main(args=None):
    rclpy.init(args=args)
    node = TeknofestRouteAgentNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
